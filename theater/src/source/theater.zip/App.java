package theater;

public class App {
	public static void main(String[] args) {
		String memcode;
		new MainMenu(memcode);
	}
}
