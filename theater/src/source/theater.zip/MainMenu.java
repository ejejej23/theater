package theater;

import java.awt.Color;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.SwingConstants;
import javax.swing.border.MatteBorder;

public class MainMenu extends JFrame implements ActionListener {
	private static final long serialVersionUID = 1L;
	private String memcode;
	// ��¥
	SimpleDateFormat sdf = new SimpleDateFormat("dd");
	Calendar cal = Calendar.getInstance();

	private TimeDAO dao = new TimeDAO();

	private JFrame fr;

	private JPanel panel1; // ù��
	private JPanel panel2; // ��°��
	private JPanel panel3; // ��°��
	private JPanel panel4; // ��°��

	private JTabbedPane tPane;

	public MainMenu(String memcode) {
		// ���� �� �ʱ�ȭ
		this.memcode = memcode;
		fr = new JFrame();
		tPane = new JTabbedPane(JTabbedPane.TOP);
		int d = cal.get(Calendar.DATE);

		panel1 = new JPanel();
		panel1.setBackground(SystemColor.window);
		panel1.setLayout(null);

		panel2 = new JPanel();
		panel2.setBackground(SystemColor.window);
		panel2.setLayout(null);

		panel3 = new JPanel();
		panel3.setBackground(SystemColor.window);
		panel3.setLayout(null);

		panel4 = new JPanel();
		panel4.setBackground(SystemColor.window);
		panel4.setLayout(null);

		// ù°��
		tPane.add((d) + "��(����)", panel1);
		
		JLabel label1_zu = new JLabel("������� : ���� ŷ��");
		ImageIcon icon1=new ImageIcon("12.png");
		label1_zu.setIcon(icon1);
		label1_zu.setHorizontalAlignment(SwingConstants.CENTER);
		label1_zu.setBounds(0, 0, 162, 86);
		panel1.add(label1_zu);
		label1_zu.setBorder(new MatteBorder(1, 1, 1, 0, (Color) new Color(227, 227, 227)));

		JLabel label1_o = new JLabel("���ǽ�8");
		label1_o.setIcon(icon1);
		label1_o.setHorizontalAlignment(SwingConstants.CENTER);
		label1_o.setBounds(0, 86, 162, 86);
		panel1.add(label1_o);
		label1_o.setBorder(new MatteBorder(0, 0, 1, 0, (Color) SystemColor.controlHighlight));

		JLabel label1_chin = new JLabel("ģ���� ���ھ�");
		ImageIcon icon2=new ImageIcon("û��.png");
		label1_chin.setIcon(icon2);
		label1_chin.setHorizontalAlignment(SwingConstants.CENTER);
		label1_chin.setBounds(0, 172, 162, 86);
		panel1.add(label1_chin);
		label1_chin.setBorder(new MatteBorder(0, 0, 1, 0, (Color) SystemColor.controlHighlight));

		JLabel label1_tam = new JLabel("Ž�� �� ����");
		ImageIcon icon3=new ImageIcon("15.png");
		label1_tam.setIcon(icon3);
		label1_tam.setHorizontalAlignment(SwingConstants.CENTER);
		label1_tam.setBounds(0, 259, 162, 86);
		panel1.add(label1_tam);
		label1_tam.setBorder(new MatteBorder(0, 0, 1, 0, (Color) SystemColor.controlHighlight));

		JLabel label1_dok = new JLabel("����");
		label1_dok.setIcon(icon3);
		label1_dok.setHorizontalAlignment(SwingConstants.CENTER);
		label1_dok.setBounds(0, 344, 162, 86);
		panel1.add(label1_dok);

		// �󿵰�/�ð�(�¼���)
		// ����
		JButton time1_zu1 = new JButton();
		time1_zu1.setHorizontalAlignment(SwingConstants.CENTER);
		time1_zu1.setBorder(new MatteBorder(1, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time1_zu1.setBounds(161, 0, 87, 86);
		panel1.add(time1_zu1);

		JButton time1_zu2 = new JButton();
		time1_zu2.setHorizontalAlignment(SwingConstants.CENTER);
		time1_zu2.setBorder(new MatteBorder(1, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time1_zu2.setBounds(248, 0, 87, 86);
		panel1.add(time1_zu2);

		JButton time1_zu3 = new JButton();
		time1_zu3.setHorizontalAlignment(SwingConstants.CENTER);
		time1_zu3.setBorder(new MatteBorder(1, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time1_zu3.setBounds(336, 0, 87, 86);
		panel1.add(time1_zu3);

		JButton time1_zu4 = new JButton();
		time1_zu4.setHorizontalAlignment(SwingConstants.CENTER);
		time1_zu4.setBorder(new MatteBorder(1, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time1_zu4.setBounds(424, 0, 87, 86);
		panel1.add(time1_zu4);

		JButton time1_zu5 = new JButton();
		time1_zu5.setHorizontalAlignment(SwingConstants.CENTER);
		time1_zu5.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(227, 227, 227)));
		time1_zu5.setBounds(510, 0, 87, 86);
		panel1.add(time1_zu5);

		// ������������
		String s1 = "2018/06/" + d;
		List<TimeDTO> list1_zu = dao.listTime1("�������", s1);
		JButton[] l1 = new JButton[5];
		l1[0] = time1_zu1;
		l1[1] = time1_zu2;
		l1[2] = time1_zu3;
		l1[3] = time1_zu4;
		l1[4] = time1_zu5;

		for (int i = 0; i < list1_zu.size(); i++) {
			StringBuffer sb = new StringBuffer();
			sb.append(list1_zu.get(i).getStartTime() + " ");
			sb.insert(2, ":");
			l1[i].setText("<html><center>" + list1_zu.get(i).getScreenName() + " ��/ " + sb.toString() + "<br>"
					+ list1_zu.get(i).getSeatNumber() + "��</center></html>");

			l1[i].addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					YemaeFrame f = new YemaeFrame(memcode, list1_zu.get(i).getScreenplayCode());
					f.setVisible(true);

				}
			});
		}

		// ���ǽ�8
		JButton time1_o1 = new JButton();
		time1_o1.setHorizontalAlignment(SwingConstants.CENTER);
		time1_o1.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time1_o1.setBounds(161, 86, 87, 86);
		panel1.add(time1_o1);

		JButton time1_o2 = new JButton();
		time1_o2.setHorizontalAlignment(SwingConstants.CENTER);
		time1_o2.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time1_o2.setBounds(248, 86, 87, 86);
		panel1.add(time1_o2);

		JButton time1_o3 = new JButton();
		time1_o3.setHorizontalAlignment(SwingConstants.CENTER);
		time1_o3.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time1_o3.setBounds(336, 86, 87, 86);
		panel1.add(time1_o3);

		JButton time1_o4 = new JButton();
		time1_o4.setHorizontalAlignment(SwingConstants.CENTER);
		time1_o4.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time1_o4.setBounds(424, 86, 87, 86);
		panel1.add(time1_o4);

		JButton time1_o5 = new JButton();
		time1_o5.setHorizontalAlignment(SwingConstants.CENTER);
		time1_o5.setBorder(new MatteBorder(0, 1, 1, 1, (Color) new Color(227, 227, 227)));
		time1_o5.setBounds(510, 86, 87, 86);
		panel1.add(time1_o5);

		// ������������
		List<TimeDTO> list1_o = dao.listTime1("���ǽ�8", s1);
		JButton[] l2 = new JButton[5];
		l2[0] = time1_o1;
		l2[1] = time1_o2;
		l2[2] = time1_o3;
		l2[3] = time1_o4;
		l2[4] = time1_o5;
		for (int i = 0; i < list1_o.size(); i++) {
			StringBuffer sb = new StringBuffer();
			sb.append(list1_o.get(i).getStartTime() + " ");
			sb.insert(2, ":");
			l2[i].setText("<html><center>" + list1_o.get(i).getScreenName() + " ��/ " + sb.toString() + "<br>"
					+ list1_o.get(i).getSeatNumber() + "��</center></html>");

			l2[i].addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					YemaeFrame f = new YemaeFrame(memcode, list1_o.get(i).getScreenplayCode());
					f.setVisible(true);

				}
			});
		}

		// ģ���� ���ھ�
		JButton time1_chin1 = new JButton();
		time1_chin1.setHorizontalAlignment(SwingConstants.CENTER);
		time1_chin1.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time1_chin1.setBounds(161, 172, 87, 86);
		panel1.add(time1_chin1);

		JButton time1_chin2 = new JButton();
		time1_chin2.setHorizontalAlignment(SwingConstants.CENTER);
		time1_chin2.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time1_chin2.setBounds(248, 172, 87, 86);
		panel1.add(time1_chin2);

		JButton time1_chin3 = new JButton();
		time1_chin3.setHorizontalAlignment(SwingConstants.CENTER);
		time1_chin3.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time1_chin3.setBounds(336, 172, 87, 86);
		panel1.add(time1_chin3);

		JButton time1_chin4 = new JButton();
		time1_chin4.setHorizontalAlignment(SwingConstants.CENTER);
		time1_chin4.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time1_chin4.setBounds(424, 172, 87, 86);
		panel1.add(time1_chin4);

		JButton time1_chin5 = new JButton();
		time1_chin5.setHorizontalAlignment(SwingConstants.CENTER);
		time1_chin5.setBorder(new MatteBorder(0, 1, 1, 1, (Color) new Color(227, 227, 227)));
		time1_chin5.setBounds(510, 172, 87, 86);
		panel1.add(time1_chin5);

		// ������������
		List<TimeDTO> list1_chin = dao.listTime1("ģ���ѱ��ھ�", s1);
		JButton[] l3 = new JButton[5];
		l3[0] = time1_chin1;
		l3[1] = time1_chin2;
		l3[2] = time1_chin3;
		l3[3] = time1_chin4;
		l3[4] = time1_chin5;
		for (int i = 0; i < list1_chin.size(); i++) {
			StringBuffer sb = new StringBuffer();
			sb.append(list1_chin.get(i).getStartTime() + " ");
			sb.insert(2, ":");
			l3[i].setText("<html><center>" + list1_chin.get(i).getScreenName() + " ��/ " + sb.toString() + "<br>"
					+ list1_chin.get(i).getSeatNumber() + "��</center></html>");

			l3[i].addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					YemaeFrame f = new YemaeFrame(memcode, list1_chin.get(i).getScreenplayCode());
					f.setVisible(true);

				}
			});
		}

		// Ž��
		JButton time1_tam1 = new JButton();
		time1_tam1.setHorizontalAlignment(SwingConstants.CENTER);
		time1_tam1.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time1_tam1.setBounds(161, 259, 87, 86);
		panel1.add(time1_tam1);

		JButton time1_tam2 = new JButton();
		time1_tam2.setHorizontalAlignment(SwingConstants.CENTER);
		time1_tam2.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time1_tam2.setBounds(248, 259, 87, 86);
		panel1.add(time1_tam2);

		JButton time1_tam3 = new JButton();
		time1_tam3.setHorizontalAlignment(SwingConstants.CENTER);
		time1_tam3.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time1_tam3.setBounds(336, 259, 87, 86);
		panel1.add(time1_tam3);

		JButton time1_tam4 = new JButton();
		time1_tam4.setHorizontalAlignment(SwingConstants.CENTER);
		time1_tam4.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time1_tam4.setBounds(424, 259, 87, 86);
		panel1.add(time1_tam4);

		JButton time1_tam5 = new JButton();
		time1_tam5.setHorizontalAlignment(SwingConstants.CENTER);
		time1_tam5.setBorder(new MatteBorder(0, 1, 1, 1, (Color) new Color(227, 227, 227)));
		time1_tam5.setBounds(510, 259, 87, 86);
		panel1.add(time1_tam5);

		// ������������
		List<TimeDTO> list1_tam = dao.listTime1("Ž��������", s1);
		JButton[] l4 = new JButton[5];
		l4[0] = time1_tam1;
		l4[1] = time1_tam2;
		l4[2] = time1_tam3;
		l4[3] = time1_tam4;
		l4[4] = time1_tam5;
		for (int i = 0; i < list1_tam.size(); i++) {
			StringBuffer sb = new StringBuffer();
			sb.append(list1_tam.get(i).getStartTime() + " ");
			sb.insert(2, ":");
			l4[i].setText("<html><center>" + list1_tam.get(i).getScreenName() + " ��/ " + sb.toString() + "<br>"
					+ list1_tam.get(i).getSeatNumber() + "��</center></html>");

			l4[i].addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					YemaeFrame f = new YemaeFrame(memcode, list1_tam.get(i).getScreenplayCode());
					f.setVisible(true);

				}
			});
		}

		// ����
		JButton time1_dok1 = new JButton();
		time1_dok1.setHorizontalAlignment(SwingConstants.CENTER);
		time1_dok1.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time1_dok1.setBounds(161, 344, 87, 86);
		panel1.add(time1_dok1);

		JButton time1_dok2 = new JButton();
		time1_dok2.setHorizontalAlignment(SwingConstants.CENTER);
		time1_dok2.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time1_dok2.setBounds(248, 344, 87, 86);
		panel1.add(time1_dok2);

		JButton time1_dok3 = new JButton();
		time1_dok3.setHorizontalAlignment(SwingConstants.CENTER);
		time1_dok3.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time1_dok3.setBounds(336, 344, 87, 86);
		panel1.add(time1_dok3);

		JButton time1_dok4 = new JButton();
		time1_dok4.setHorizontalAlignment(SwingConstants.CENTER);
		time1_dok4.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time1_dok4.setBounds(424, 344, 87, 86);
		panel1.add(time1_dok4);

		JButton time1_dok5 = new JButton();
		time1_dok5.setHorizontalAlignment(SwingConstants.CENTER);
		time1_dok5.setBorder(new MatteBorder(0, 1, 1, 1, (Color) new Color(227, 227, 227)));
		time1_dok5.setBounds(510, 344, 87, 86);
		panel1.add(time1_dok5);

		// ������������
		List<TimeDTO> list1_dok = dao.listTime1("����", s1);
		JButton[] l5 = new JButton[5];
		l5[0] = time1_dok1;
		l5[1] = time1_dok2;
		l5[2] = time1_dok3;
		l5[3] = time1_dok4;
		l5[4] = time1_dok5;
		for (int i = 0; i < list1_dok.size(); i++) {
			StringBuffer sb = new StringBuffer();
			sb.append(list1_dok.get(i).getStartTime() + " ");
			sb.insert(2, ":");
			l5[i].setText("<html><center>" + list1_dok.get(i).getScreenName() + " ��/ " + sb.toString() + "<br>"
					+ list1_dok.get(i).getSeatNumber() + "��</center></html>");

			l5[i].addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					YemaeFrame f = new YemaeFrame(memcode, list1_dok.get(i).getScreenplayCode());
					f.setVisible(true);

				}
			});
		}

		// ��°��
		tPane.add((d + 1) + "��(����)", panel2);

		JLabel label2_zu = new JLabel("������� : ���� ŷ��");
		label2_zu.setHorizontalAlignment(SwingConstants.CENTER);
		label2_zu.setBounds(0, 0, 162, 86);
		panel2.add(label2_zu);
		label2_zu.setBorder(new MatteBorder(1, 1, 1, 0, (Color) new Color(227, 227, 227)));

		JLabel label2_o = new JLabel("���ǽ�8");
		label2_o.setHorizontalAlignment(SwingConstants.CENTER);
		label2_o.setBounds(0, 86, 162, 86);
		panel2.add(label2_o);
		label2_o.setBorder(new MatteBorder(0, 0, 1, 0, (Color) SystemColor.controlHighlight));

		JLabel label2_chin = new JLabel("ģ���� ���ھ�");
		label2_chin.setHorizontalAlignment(SwingConstants.CENTER);
		label2_chin.setBounds(0, 172, 162, 86);
		panel2.add(label2_chin);
		label2_chin.setBorder(new MatteBorder(0, 0, 1, 0, (Color) SystemColor.controlHighlight));

		JLabel label2_tam = new JLabel("Ž�� �� ����");
		label2_tam.setHorizontalAlignment(SwingConstants.CENTER);
		label2_tam.setBounds(0, 259, 162, 86);
		panel2.add(label2_tam);
		label2_tam.setBorder(new MatteBorder(0, 0, 1, 0, (Color) SystemColor.controlHighlight));

		JLabel label2_dok = new JLabel("����");
		label2_dok.setHorizontalAlignment(SwingConstants.CENTER);
		label2_dok.setBounds(0, 344, 162, 86);
		panel2.add(label2_dok);

		// �󿵰�/�ð�(�¼���)
		// ����
		JButton time2_zu1 = new JButton();
		time2_zu1.setHorizontalAlignment(SwingConstants.CENTER);
		time2_zu1.setBorder(new MatteBorder(1, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time2_zu1.setBounds(161, 0, 87, 86);
		panel2.add(time2_zu1);

		JButton time2_zu2 = new JButton();
		time2_zu2.setHorizontalAlignment(SwingConstants.CENTER);
		time2_zu2.setBorder(new MatteBorder(1, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time2_zu2.setBounds(248, 0, 87, 86);
		panel2.add(time2_zu2);

		JButton time2_zu3 = new JButton();
		time2_zu3.setHorizontalAlignment(SwingConstants.CENTER);
		time2_zu3.setBorder(new MatteBorder(1, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time2_zu3.setBounds(336, 0, 87, 86);
		panel2.add(time2_zu3);

		JButton time2_zu4 = new JButton();
		time2_zu4.setHorizontalAlignment(SwingConstants.CENTER);
		time2_zu4.setBorder(new MatteBorder(1, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time2_zu4.setBounds(424, 0, 87, 86);
		panel2.add(time2_zu4);

		JButton time2_zu5 = new JButton();
		time2_zu5.setHorizontalAlignment(SwingConstants.CENTER);
		time2_zu5.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(227, 227, 227)));
		time2_zu5.setBounds(510, 0, 87, 86);
		panel2.add(time2_zu5);

		// ������������
		String s2 = "2018/06/" + (int) (d + 1);
		List<TimeDTO> list2_zu = dao.listTime1("�������", s2);
		JButton[] l6 = new JButton[5];
		l6[0] = time2_zu1;
		l6[1] = time2_zu2;
		l6[2] = time2_zu3;
		l6[3] = time2_zu4;
		l6[4] = time2_zu5;
		for (int i = 0; i < list2_zu.size(); i++) {
			StringBuffer sb = new StringBuffer();
			sb.append(list2_zu.get(i).getStartTime() + " ");
			sb.insert(2, ":");
			l6[i].setText("<html><center>" + list2_zu.get(i).getScreenName() + " ��/ " + sb.toString() + "<br>"
					+ list2_zu.get(i).getSeatNumber() + "��</center></html>");

			l6[i].addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					YemaeFrame f = new YemaeFrame(memcode, list2_zu.get(i).getScreenplayCode());
					f.setVisible(true);

				}
			});
		}

		// ���ǽ�8
		JButton time2_o1 = new JButton();
		time2_o1.setHorizontalAlignment(SwingConstants.CENTER);
		time2_o1.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time2_o1.setBounds(161, 86, 87, 86);
		panel2.add(time2_o1);

		JButton time2_o2 = new JButton();
		time2_o2.setHorizontalAlignment(SwingConstants.CENTER);
		time2_o2.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time2_o2.setBounds(248, 86, 87, 86);
		panel2.add(time2_o2);

		JButton time2_o3 = new JButton();
		time2_o3.setHorizontalAlignment(SwingConstants.CENTER);
		time2_o3.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time2_o3.setBounds(336, 86, 87, 86);
		panel2.add(time2_o3);

		JButton time2_o4 = new JButton();
		time2_o4.setHorizontalAlignment(SwingConstants.CENTER);
		time2_o4.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time2_o4.setBounds(424, 86, 87, 86);
		panel2.add(time2_o4);

		JButton time2_o5 = new JButton();
		time2_o5.setHorizontalAlignment(SwingConstants.CENTER);
		time2_o5.setBorder(new MatteBorder(0, 1, 1, 1, (Color) new Color(227, 227, 227)));
		time2_o5.setBounds(510, 86, 87, 86);
		panel2.add(time2_o5);

		// ������������
		List<TimeDTO> list2_o = dao.listTime1("���ǽ�8", s2);
		JButton[] l7 = new JButton[5];
		l7[0] = time2_o1;
		l7[1] = time2_o2;
		l7[2] = time2_o3;
		l7[3] = time2_o4;
		l7[4] = time2_o5;
		for (int i = 0; i < list2_o.size(); i++) {
			StringBuffer sb = new StringBuffer();
			sb.append(list2_o.get(i).getStartTime() + " ");
			sb.insert(2, ":");
			l7[i].setText("<html><center>" + list2_o.get(i).getScreenName() + " ��/ " + sb.toString() + "<br>"
					+ list2_o.get(i).getSeatNumber() + "��</center></html>");

			l7[i].addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					YemaeFrame f = new YemaeFrame(memcode, list2_o.get(i).getScreenplayCode());
					f.setVisible(true);

				}
			});
		}

		// ģ���� ���ھ�
		JButton time2_chin1 = new JButton();
		time2_chin1.setHorizontalAlignment(SwingConstants.CENTER);
		time2_chin1.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time2_chin1.setBounds(161, 172, 87, 86);
		panel2.add(time2_chin1);

		JButton time2_chin2 = new JButton();
		time2_chin2.setHorizontalAlignment(SwingConstants.CENTER);
		time2_chin2.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time2_chin2.setBounds(248, 172, 87, 86);
		panel2.add(time2_chin2);

		JButton time2_chin3 = new JButton();
		time2_chin3.setHorizontalAlignment(SwingConstants.CENTER);
		time2_chin3.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time2_chin3.setBounds(336, 172, 87, 86);
		panel2.add(time2_chin3);

		JButton time2_chin4 = new JButton();
		time2_chin4.setHorizontalAlignment(SwingConstants.CENTER);
		time2_chin4.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time2_chin4.setBounds(424, 172, 87, 86);
		panel2.add(time2_chin4);

		JButton time2_chin5 = new JButton();
		time2_chin5.setHorizontalAlignment(SwingConstants.CENTER);
		time2_chin5.setBorder(new MatteBorder(0, 1, 1, 1, (Color) new Color(227, 227, 227)));
		time2_chin5.setBounds(510, 172, 87, 86);
		panel2.add(time2_chin5);

		// ������������
		List<TimeDTO> list2_chin = dao.listTime1("ģ���ѱ��ھ�", s2);
		JButton[] l8 = new JButton[5];
		l8[0] = time2_chin1;
		l8[1] = time2_chin2;
		l8[2] = time2_chin3;
		l8[3] = time2_chin4;
		l8[4] = time2_chin5;
		for (int i = 0; i < list2_chin.size(); i++) {
			StringBuffer sb = new StringBuffer();
			sb.append(list2_chin.get(i).getStartTime() + " ");
			sb.insert(2, ":");
			l8[i].setText("<html><center>" + list2_chin.get(i).getScreenName() + " ��/ " + sb.toString() + "<br>"
					+ list2_chin.get(i).getSeatNumber() + "��</center></html>");

			l8[i].addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					YemaeFrame f = new YemaeFrame(memcode, list2_chin.get(i).getScreenplayCode());
					f.setVisible(true);

				}
			});
		}

		// Ž��
		JButton time2_tam1 = new JButton();
		time2_tam1.setHorizontalAlignment(SwingConstants.CENTER);
		time2_tam1.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time2_tam1.setBounds(161, 259, 87, 86);
		panel2.add(time2_tam1);

		JButton time2_tam2 = new JButton();
		time2_tam2.setHorizontalAlignment(SwingConstants.CENTER);
		time2_tam2.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time2_tam2.setBounds(248, 259, 87, 86);
		panel2.add(time2_tam2);

		JButton time2_tam3 = new JButton();
		time2_tam3.setHorizontalAlignment(SwingConstants.CENTER);
		time2_tam3.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time2_tam3.setBounds(336, 259, 87, 86);
		panel2.add(time2_tam3);

		JButton time2_tam4 = new JButton();
		time2_tam4.setHorizontalAlignment(SwingConstants.CENTER);
		time2_tam4.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time2_tam4.setBounds(424, 259, 87, 86);
		panel2.add(time2_tam4);

		JButton time2_tam5 = new JButton();
		time2_tam5.setHorizontalAlignment(SwingConstants.CENTER);
		time2_tam5.setBorder(new MatteBorder(0, 1, 1, 1, (Color) new Color(227, 227, 227)));
		time2_tam5.setBounds(510, 259, 87, 86);
		panel2.add(time2_tam5);

		// ������������
		List<TimeDTO> list2_tam = dao.listTime1("Ž��������", s2);
		JButton[] l9 = new JButton[5];
		l9[0] = time2_tam1;
		l9[1] = time2_tam2;
		l9[2] = time2_tam3;
		l9[3] = time2_tam4;
		l9[4] = time2_tam5;
		for (int i = 0; i < list2_tam.size(); i++) {
			StringBuffer sb = new StringBuffer();
			sb.append(list2_tam.get(i).getStartTime() + " ");
			sb.insert(2, ":");
			l9[i].setText("<html><center>" + list2_tam.get(i).getScreenName() + " ��/ " + sb.toString() + "<br>"
					+ list2_tam.get(i).getSeatNumber() + "��</center></html>");

			l9[i].addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					YemaeFrame f = new YemaeFrame(memcode, list2_tam.get(i).getScreenplayCode());
					f.setVisible(true);

				}
			});
		}

		// ����
		JButton time2_dok1 = new JButton();
		time2_dok1.setHorizontalAlignment(SwingConstants.CENTER);
		time2_dok1.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time2_dok1.setBounds(161, 344, 87, 86);
		panel2.add(time2_dok1);

		JButton time2_dok2 = new JButton();
		time2_dok2.setHorizontalAlignment(SwingConstants.CENTER);
		time2_dok2.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time2_dok2.setBounds(248, 344, 87, 86);
		panel2.add(time2_dok2);

		JButton time2_dok3 = new JButton();
		time2_dok3.setHorizontalAlignment(SwingConstants.CENTER);
		time2_dok3.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time2_dok3.setBounds(336, 344, 87, 86);
		panel2.add(time2_dok3);

		JButton time2_dok4 = new JButton();
		time2_dok4.setHorizontalAlignment(SwingConstants.CENTER);
		time2_dok4.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time2_dok4.setBounds(424, 344, 87, 86);
		panel2.add(time2_dok4);

		JButton time2_dok5 = new JButton();
		time2_dok5.setHorizontalAlignment(SwingConstants.CENTER);
		time2_dok5.setBorder(new MatteBorder(0, 1, 1, 1, (Color) new Color(227, 227, 227)));
		time2_dok5.setBounds(510, 344, 87, 86);
		panel2.add(time2_dok5);

		// ������������
		List<TimeDTO> list2_dok = dao.listTime1("����", s2);
		JButton[] l10 = new JButton[5];
		l10[0] = time2_dok1;
		l10[1] = time2_dok2;
		l10[2] = time2_dok3;
		l10[3] = time2_dok4;
		l10[4] = time2_dok5;
		for (int i = 0; i < list2_dok.size(); i++) {
			StringBuffer sb = new StringBuffer();
			sb.append(list2_dok.get(i).getStartTime() + " ");
			sb.insert(2, ":");
			l10[i].setText("<html><center>" + list2_dok.get(i).getScreenName() + " ��/ " + sb.toString() + "<br>"
					+ list2_dok.get(i).getSeatNumber() + "��</center></html>");

			l10[i].addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					YemaeFrame f = new YemaeFrame(memcode, list2_dok.get(i).getScreenplayCode());
					f.setVisible(true);

				}
			});
		}

		// ��°��
		tPane.add((d + 2) + "��", panel3);

		JLabel label3_zu = new JLabel("������� : ���� ŷ��");
		label3_zu.setHorizontalAlignment(SwingConstants.CENTER);
		label3_zu.setBounds(0, 0, 162, 86);
		panel3.add(label3_zu);
		label3_zu.setBorder(new MatteBorder(1, 1, 1, 0, (Color) new Color(227, 227, 227)));

		JLabel label3_o = new JLabel("���ǽ�8");
		label3_o.setHorizontalAlignment(SwingConstants.CENTER);
		label3_o.setBounds(0, 86, 162, 86);
		panel3.add(label3_o);
		label3_o.setBorder(new MatteBorder(0, 0, 1, 0, (Color) SystemColor.controlHighlight));

		JLabel label3_chin = new JLabel("ģ���� ���ھ�");
		label3_chin.setHorizontalAlignment(SwingConstants.CENTER);
		label3_chin.setBounds(0, 172, 162, 86);
		panel3.add(label3_chin);
		label3_chin.setBorder(new MatteBorder(0, 0, 1, 0, (Color) SystemColor.controlHighlight));

		JLabel label3_tam = new JLabel("Ž�� �� ����");
		label3_tam.setHorizontalAlignment(SwingConstants.CENTER);
		label3_tam.setBounds(0, 259, 162, 86);
		panel3.add(label3_tam);
		label3_tam.setBorder(new MatteBorder(0, 0, 1, 0, (Color) SystemColor.controlHighlight));

		JLabel label3_dok = new JLabel("����");
		label3_dok.setHorizontalAlignment(SwingConstants.CENTER);
		label3_dok.setBounds(0, 344, 162, 86);
		panel3.add(label3_dok);

		// �󿵰�/�ð�(�¼���)
		// ����
		JButton time3_zu1 = new JButton();
		time3_zu1.setHorizontalAlignment(SwingConstants.CENTER);
		time3_zu1.setBorder(new MatteBorder(1, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time3_zu1.setBounds(161, 0, 87, 86);
		panel3.add(time3_zu1);

		JButton time3_zu2 = new JButton();
		time3_zu2.setHorizontalAlignment(SwingConstants.CENTER);
		time3_zu2.setBorder(new MatteBorder(1, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time3_zu2.setBounds(248, 0, 87, 86);
		panel3.add(time3_zu2);

		JButton time3_zu3 = new JButton();
		time3_zu3.setHorizontalAlignment(SwingConstants.CENTER);
		time3_zu3.setBorder(new MatteBorder(1, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time3_zu3.setBounds(336, 0, 87, 86);
		panel3.add(time3_zu3);

		JButton time3_zu4 = new JButton();
		time3_zu4.setHorizontalAlignment(SwingConstants.CENTER);
		time3_zu4.setBorder(new MatteBorder(1, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time3_zu4.setBounds(424, 0, 87, 86);
		panel3.add(time3_zu4);

		JButton time3_zu5 = new JButton();
		time3_zu5.setHorizontalAlignment(SwingConstants.CENTER);
		time3_zu5.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(227, 227, 227)));
		time3_zu5.setBounds(510, 0, 87, 86);
		panel3.add(time3_zu5);

		// ������������
		String s3 = "2018/06/" + (int) (d + 2);
		List<TimeDTO> list3_zu = dao.listTime1("�������", s3);
		JButton[] l11 = new JButton[5];
		l11[0] = time3_zu1;
		l11[1] = time3_zu2;
		l11[2] = time3_zu3;
		l11[3] = time3_zu4;
		l11[4] = time3_zu5;
		for (int i = 0; i < list3_zu.size(); i++) {
			StringBuffer sb = new StringBuffer();
			sb.append(list3_zu.get(i).getStartTime() + " ");
			sb.insert(2, ":");
			l11[i].setText("<html><center>" + list3_zu.get(i).getScreenName() + " ��/ " + sb.toString() + "<br>"
					+ list3_zu.get(i).getSeatNumber() + "��</center></html>");

			l11[i].addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					YemaeFrame f = new YemaeFrame(memcode, list3_zu.get(i).getScreenplayCode());
					f.setVisible(true);

				}
			});
		}

		// ���ǽ�8
		JButton time3_o1 = new JButton();
		time3_o1.setHorizontalAlignment(SwingConstants.CENTER);
		time3_o1.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time3_o1.setBounds(161, 86, 87, 86);
		panel3.add(time3_o1);

		JButton time3_o2 = new JButton();
		time3_o2.setHorizontalAlignment(SwingConstants.CENTER);
		time3_o2.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time3_o2.setBounds(248, 86, 87, 86);
		panel3.add(time3_o2);

		JButton time3_o3 = new JButton();
		time3_o3.setHorizontalAlignment(SwingConstants.CENTER);
		time3_o3.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time3_o3.setBounds(336, 86, 87, 86);
		panel3.add(time3_o3);

		JButton time3_o4 = new JButton();
		time3_o4.setHorizontalAlignment(SwingConstants.CENTER);
		time3_o4.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time3_o4.setBounds(424, 86, 87, 86);
		panel3.add(time3_o4);

		JButton time3_o5 = new JButton();
		time3_o5.setHorizontalAlignment(SwingConstants.CENTER);
		time3_o5.setBorder(new MatteBorder(0, 1, 1, 1, (Color) new Color(227, 227, 227)));
		time3_o5.setBounds(510, 86, 87, 86);
		panel3.add(time3_o5);

		// ������������
		List<TimeDTO> list3_o = dao.listTime1("���ǽ�8", s3);
		JButton[] l12 = new JButton[5];
		l12[0] = time3_o1;
		l12[1] = time3_o2;
		l12[2] = time3_o3;
		l12[3] = time3_o4;
		l12[4] = time3_o5;
		for (int i = 0; i < list3_o.size(); i++) {
			StringBuffer sb = new StringBuffer();
			sb.append(list3_o.get(i).getStartTime() + " ");
			sb.insert(2, ":");
			l12[i].setText("<html><center>" + list3_o.get(i).getScreenName() + " ��/ " + sb.toString() + "<br>"
					+ list3_o.get(i).getSeatNumber() + "��</center></html>");

			l12[i].addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					YemaeFrame f = new YemaeFrame(memcode, list3_o.get(i).getScreenplayCode());
					f.setVisible(true);

				}
			});
		}

		// ģ���� ���ھ�
		JButton time3_chin1 = new JButton();
		time3_chin1.setHorizontalAlignment(SwingConstants.CENTER);
		time3_chin1.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time3_chin1.setBounds(161, 172, 87, 86);
		panel3.add(time3_chin1);

		JButton time3_chin2 = new JButton();
		time3_chin2.setHorizontalAlignment(SwingConstants.CENTER);
		time3_chin2.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time3_chin2.setBounds(248, 172, 87, 86);
		panel3.add(time3_chin2);

		JButton time3_chin3 = new JButton();
		time3_chin3.setHorizontalAlignment(SwingConstants.CENTER);
		time3_chin3.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time3_chin3.setBounds(336, 172, 87, 86);
		panel3.add(time3_chin3);

		JButton time3_chin4 = new JButton();
		time3_chin4.setHorizontalAlignment(SwingConstants.CENTER);
		time3_chin4.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time3_chin4.setBounds(424, 172, 87, 86);
		panel3.add(time3_chin4);

		JButton time3_chin5 = new JButton();
		time3_chin5.setHorizontalAlignment(SwingConstants.CENTER);
		time3_chin5.setBorder(new MatteBorder(0, 1, 1, 1, (Color) new Color(227, 227, 227)));
		time3_chin5.setBounds(510, 172, 87, 86);
		panel3.add(time3_chin5);

		// ������������
		List<TimeDTO> list3_chin = dao.listTime1("ģ���ѱ��ھ�", s3);
		JButton[] l13 = new JButton[5];
		l13[0] = time3_chin1;
		l13[1] = time3_chin2;
		l13[2] = time3_chin3;
		l13[3] = time3_chin4;
		l13[4] = time3_chin5;
		for (int i = 0; i < list3_chin.size(); i++) {
			StringBuffer sb = new StringBuffer();
			sb.append(list3_chin.get(i).getStartTime() + " ");
			sb.insert(2, ":");
			l13[i].setText("<html><center>" + list3_chin.get(i).getScreenName() + " ��/ " + sb.toString() + "<br>"
					+ list3_chin.get(i).getSeatNumber() + "��</center></html>");

			l13[i].addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					YemaeFrame f = new YemaeFrame(memcode, list3_chin.get(i).getScreenplayCode());
					f.setVisible(true);

				}
			});
		}

		// Ž��
		JButton time3_tam1 = new JButton();
		time3_tam1.setHorizontalAlignment(SwingConstants.CENTER);
		time3_tam1.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time3_tam1.setBounds(161, 259, 87, 86);
		panel3.add(time3_tam1);

		JButton time3_tam2 = new JButton();
		time3_tam2.setHorizontalAlignment(SwingConstants.CENTER);
		time3_tam2.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time3_tam2.setBounds(248, 259, 87, 86);
		panel3.add(time3_tam2);

		JButton time3_tam3 = new JButton();
		time3_tam3.setHorizontalAlignment(SwingConstants.CENTER);
		time3_tam3.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time3_tam3.setBounds(336, 259, 87, 86);
		panel3.add(time3_tam3);

		JButton time3_tam4 = new JButton();
		time3_tam4.setHorizontalAlignment(SwingConstants.CENTER);
		time3_tam4.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time3_tam4.setBounds(424, 259, 87, 86);
		panel3.add(time3_tam4);

		JButton time3_tam5 = new JButton();
		time3_tam5.setHorizontalAlignment(SwingConstants.CENTER);
		time3_tam5.setBorder(new MatteBorder(0, 1, 1, 1, (Color) new Color(227, 227, 227)));
		time3_tam5.setBounds(510, 259, 87, 86);
		panel3.add(time3_tam5);

		// ������������
		List<TimeDTO> list3_tam = dao.listTime1("Ž��������", s3);
		JButton[] l14 = new JButton[5];
		l14[0] = time3_tam1;
		l14[1] = time3_tam2;
		l14[2] = time3_tam3;
		l14[3] = time3_tam4;
		l14[4] = time3_tam5;
		for (int i = 0; i < list3_tam.size(); i++) {
			StringBuffer sb = new StringBuffer();
			sb.append(list3_tam.get(i).getStartTime() + " ");
			sb.insert(2, ":");
			l14[i].setText("<html><center>" + list3_tam.get(i).getScreenName() + " ��/ " + sb.toString() + "<br>"
					+ list3_tam.get(i).getSeatNumber() + "��</center></html>");

			l14[i].addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					YemaeFrame f = new YemaeFrame(memcode, list3_tam.get(i).getScreenplayCode());
					f.setVisible(true);

				}
			});
		}

		// ����
		JButton time3_dok1 = new JButton();
		time3_dok1.setHorizontalAlignment(SwingConstants.CENTER);
		time3_dok1.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time3_dok1.setBounds(161, 344, 87, 86);
		panel3.add(time3_dok1);

		JButton time3_dok2 = new JButton();
		time3_dok2.setHorizontalAlignment(SwingConstants.CENTER);
		time3_dok2.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time3_dok2.setBounds(248, 344, 87, 86);
		panel3.add(time3_dok2);

		JButton time3_dok3 = new JButton();
		time3_dok3.setHorizontalAlignment(SwingConstants.CENTER);
		time3_dok3.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time3_dok3.setBounds(336, 344, 87, 86);
		panel3.add(time3_dok3);

		JButton time3_dok4 = new JButton();
		time3_dok4.setHorizontalAlignment(SwingConstants.CENTER);
		time3_dok4.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time3_dok4.setBounds(424, 344, 87, 86);
		panel3.add(time3_dok4);

		JButton time3_dok5 = new JButton();
		time3_dok5.setHorizontalAlignment(SwingConstants.CENTER);
		time3_dok5.setBorder(new MatteBorder(0, 1, 1, 1, (Color) new Color(227, 227, 227)));
		time3_dok5.setBounds(510, 344, 87, 86);
		panel3.add(time3_dok5);

		// ������������
		List<TimeDTO> list3_dok = dao.listTime1("����", s3);
		JButton[] l15 = new JButton[5];
		l15[0] = time3_dok1;
		l15[1] = time3_dok2;
		l15[2] = time3_dok3;
		l15[3] = time3_dok4;
		l15[4] = time3_dok5;
		for (int i = 0; i < list3_dok.size(); i++) {
			StringBuffer sb = new StringBuffer();
			sb.append(list3_dok.get(i).getStartTime() + " ");
			sb.insert(2, ":");
			l15[i].setText("<html><center>" + list3_dok.get(i).getScreenName() + " ��/ " + sb.toString() + "<br>"
					+ list3_dok.get(i).getSeatNumber() + "��</center></html>");
			
			l15[i].addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					YemaeFrame f = new YemaeFrame(memcode, list3_dok.get(i).getScreenplayCode());
					f.setVisible(true);

				}
			});
		}

		// ��°��
		tPane.add((d + 3) + "��", panel4);

		JLabel label4_zu = new JLabel("������� : ���� ŷ��");
		label4_zu.setHorizontalAlignment(SwingConstants.CENTER);
		label4_zu.setBounds(0, 0, 162, 86);
		panel4.add(label4_zu);
		label4_zu.setBorder(new MatteBorder(1, 1, 1, 0, (Color) new Color(227, 227, 227)));

		JLabel label4_o = new JLabel("���ǽ�8");
		label4_o.setHorizontalAlignment(SwingConstants.CENTER);
		label4_o.setBounds(0, 86, 162, 86);
		panel4.add(label4_o);
		label4_o.setBorder(new MatteBorder(0, 0, 1, 0, (Color) SystemColor.controlHighlight));

		JLabel label4_chin = new JLabel("ģ���� ���ھ�");
		label4_chin.setHorizontalAlignment(SwingConstants.CENTER);
		label4_chin.setBounds(0, 172, 162, 86);
		panel4.add(label4_chin);
		label4_chin.setBorder(new MatteBorder(0, 0, 1, 0, (Color) SystemColor.controlHighlight));

		JLabel label4_tam = new JLabel("Ž�� �� ����");
		label4_tam.setHorizontalAlignment(SwingConstants.CENTER);
		label4_tam.setBounds(0, 259, 162, 86);
		panel4.add(label4_tam);
		label4_tam.setBorder(new MatteBorder(0, 0, 1, 0, (Color) SystemColor.controlHighlight));

		JLabel label4_dok = new JLabel("����");
		label4_dok.setHorizontalAlignment(SwingConstants.CENTER);
		label4_dok.setBounds(0, 344, 162, 86);
		panel4.add(label4_dok);

		// �󿵰�/�ð�(�¼���)
		// ����
		JButton time4_zu1 = new JButton();
		time4_zu1.setHorizontalAlignment(SwingConstants.CENTER);
		time4_zu1.setBorder(new MatteBorder(1, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time4_zu1.setBounds(161, 0, 87, 86);
		panel4.add(time4_zu1);

		JButton time4_zu2 = new JButton();
		time4_zu2.setHorizontalAlignment(SwingConstants.CENTER);
		time4_zu2.setBorder(new MatteBorder(1, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time4_zu2.setBounds(248, 0, 87, 86);
		panel4.add(time4_zu2);

		JButton time4_zu3 = new JButton();
		time4_zu3.setHorizontalAlignment(SwingConstants.CENTER);
		time4_zu3.setBorder(new MatteBorder(1, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time4_zu3.setBounds(336, 0, 87, 86);
		panel4.add(time4_zu3);

		JButton time4_zu4 = new JButton();
		time4_zu4.setHorizontalAlignment(SwingConstants.CENTER);
		time4_zu4.setBorder(new MatteBorder(1, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time4_zu4.setBounds(424, 0, 87, 86);
		panel4.add(time4_zu4);

		JButton time4_zu5 = new JButton();
		time4_zu5.setHorizontalAlignment(SwingConstants.CENTER);
		time4_zu5.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(227, 227, 227)));
		time4_zu5.setBounds(510, 0, 87, 86);
		panel4.add(time4_zu5);

		// ������������
		String s4 = "2018/06/" + (int) (d + 3);
		List<TimeDTO> list4_zu = dao.listTime1("�������", s4);
		JButton[] l16 = new JButton[5];
		l16[0] = time4_zu1;
		l16[1] = time4_zu2;
		l16[2] = time4_zu3;
		l16[3] = time4_zu4;
		l16[4] = time4_zu5;
		for (int i = 0; i < list4_zu.size(); i++) {
			StringBuffer sb = new StringBuffer();
			sb.append(list4_zu.get(i).getStartTime() + " ");
			sb.insert(2, ":");
			l16[i].setText("<html><center>" + list4_zu.get(i).getScreenName() + " ��/ " + sb.toString() + "<br>"
					+ list4_zu.get(i).getSeatNumber() + "��</center></html>");
			
			l16[i].addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					YemaeFrame f = new YemaeFrame(memcode, list4_zu.get(i).getScreenplayCode());
					f.setVisible(true);

				}
			});
		}

		// ���ǽ�8
		JButton time4_o1 = new JButton();
		time4_o1.setHorizontalAlignment(SwingConstants.CENTER);
		time4_o1.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time4_o1.setBounds(161, 86, 87, 86);
		panel4.add(time4_o1);

		JButton time4_o2 = new JButton();
		time4_o2.setHorizontalAlignment(SwingConstants.CENTER);
		time4_o2.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time4_o2.setBounds(248, 86, 87, 86);
		panel4.add(time4_o2);

		JButton time4_o3 = new JButton();
		time4_o3.setHorizontalAlignment(SwingConstants.CENTER);
		time4_o3.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time4_o3.setBounds(336, 86, 87, 86);
		panel4.add(time4_o3);

		JButton time4_o4 = new JButton();
		time4_o4.setHorizontalAlignment(SwingConstants.CENTER);
		time4_o4.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time4_o4.setBounds(424, 86, 87, 86);
		panel4.add(time4_o4);

		JButton time4_o5 = new JButton();
		time4_o5.setHorizontalAlignment(SwingConstants.CENTER);
		time4_o5.setBorder(new MatteBorder(0, 1, 1, 1, (Color) new Color(227, 227, 227)));
		time4_o5.setBounds(510, 86, 87, 86);
		panel4.add(time4_o5);

		// ������������
		List<TimeDTO> list4_o = dao.listTime1("���ǽ�8", s4);
		JButton[] l17 = new JButton[5];
		l17[0] = time3_o1;
		l17[1] = time3_o2;
		l17[2] = time3_o3;
		l17[3] = time3_o4;
		l17[4] = time3_o5;
		for (int i = 0; i < list4_o.size(); i++) {
			StringBuffer sb = new StringBuffer();
			sb.append(list4_o.get(i).getStartTime() + " ");
			sb.insert(2, ":");
			l17[i].setText("<html><center>" + list4_o.get(i).getScreenName() + " ��/ " + sb.toString() + "<br>"
					+ list4_o.get(i).getSeatNumber() + "��</center></html>");
			
			l17[i].addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					YemaeFrame f = new YemaeFrame(memcode, list4_o.get(i).getScreenplayCode());
					f.setVisible(true);

				}
			});
		}

		// ģ���� ���ھ�
		JButton time4_chin1 = new JButton();
		time4_chin1.setHorizontalAlignment(SwingConstants.CENTER);
		time4_chin1.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time4_chin1.setBounds(161, 172, 87, 86);
		panel4.add(time4_chin1);

		JButton time4_chin2 = new JButton();
		time4_chin2.setHorizontalAlignment(SwingConstants.CENTER);
		time4_chin2.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time4_chin2.setBounds(248, 172, 87, 86);
		panel4.add(time4_chin2);

		JButton time4_chin3 = new JButton();
		time4_chin3.setHorizontalAlignment(SwingConstants.CENTER);
		time4_chin3.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time4_chin3.setBounds(336, 172, 87, 86);
		panel4.add(time4_chin3);

		JButton time4_chin4 = new JButton();
		time4_chin4.setHorizontalAlignment(SwingConstants.CENTER);
		time4_chin4.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time4_chin4.setBounds(424, 172, 87, 86);
		panel4.add(time4_chin4);

		JButton time4_chin5 = new JButton();
		time4_chin5.setHorizontalAlignment(SwingConstants.CENTER);
		time4_chin5.setBorder(new MatteBorder(0, 1, 1, 1, (Color) new Color(227, 227, 227)));
		time4_chin5.setBounds(510, 172, 87, 86);
		panel4.add(time4_chin5);

		// ������������
		List<TimeDTO> list4_chin = dao.listTime1("ģ���ѱ��ھ�", s4);
		JButton[] l18 = new JButton[5];
		l18[0] = time4_chin1;
		l18[1] = time4_chin2;
		l18[2] = time4_chin3;
		l18[3] = time4_chin4;
		l18[4] = time4_chin5;
		for (int i = 0; i < list4_chin.size(); i++) {
			StringBuffer sb = new StringBuffer();
			sb.append(list4_chin.get(i).getStartTime() + " ");
			sb.insert(2, ":");
			l18[i].setText("<html><center>" + list4_chin.get(i).getScreenName() + " ��/ " + sb.toString() + "<br>"
					+ list4_chin.get(i).getSeatNumber() + "��</center></html>");
			
			l18[i].addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					YemaeFrame f = new YemaeFrame(memcode, list4_chin.get(i).getScreenplayCode());
					f.setVisible(true);

				}
			});
			
		}

		// Ž��
		JButton time4_tam1 = new JButton();
		time4_tam1.setHorizontalAlignment(SwingConstants.CENTER);
		time4_tam1.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time4_tam1.setBounds(161, 259, 87, 86);
		panel4.add(time4_tam1);

		JButton time4_tam2 = new JButton();
		time4_tam2.setHorizontalAlignment(SwingConstants.CENTER);
		time4_tam2.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time4_tam2.setBounds(248, 259, 87, 86);
		panel4.add(time4_tam2);

		JButton time4_tam3 = new JButton();
		time4_tam3.setHorizontalAlignment(SwingConstants.CENTER);
		time4_tam3.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time4_tam3.setBounds(336, 259, 87, 86);
		panel4.add(time4_tam3);

		JButton time4_tam4 = new JButton();
		time4_tam4.setHorizontalAlignment(SwingConstants.CENTER);
		time4_tam4.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time4_tam4.setBounds(424, 259, 87, 86);
		panel4.add(time4_tam4);

		JButton time4_tam5 = new JButton();
		time4_tam5.setHorizontalAlignment(SwingConstants.CENTER);
		time4_tam5.setBorder(new MatteBorder(0, 1, 1, 1, (Color) new Color(227, 227, 227)));
		time4_tam5.setBounds(510, 259, 87, 86);
		panel4.add(time4_tam5);

		// ������������
		List<TimeDTO> list4_tam = dao.listTime1("Ž��������", s4);
		JButton[] l19 = new JButton[5];
		l19[0] = time4_tam1;
		l19[1] = time4_tam2;
		l19[2] = time4_tam3;
		l19[3] = time4_tam4;
		l19[4] = time4_tam5;
		for (int i = 0; i < list4_tam.size(); i++) {
			StringBuffer sb = new StringBuffer();
			sb.append(list4_tam.get(i).getStartTime() + " ");
			sb.insert(2, ":");
			l19[i].setText("<html><center>" + list4_tam.get(i).getScreenName() + " ��/ " + sb.toString() + "<br>"
					+ list4_tam.get(i).getSeatNumber() + "��</center></html>");

			l19[i].addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					YemaeFrame f = new YemaeFrame(memcode, list4_tam.get(i).getScreenplayCode());
					f.setVisible(true);

				}
			});
			
		}

		// ����
		JButton time4_dok1 = new JButton();
		time4_dok1.setHorizontalAlignment(SwingConstants.CENTER);
		time4_dok1.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time4_dok1.setBounds(161, 344, 87, 86);
		panel4.add(time4_dok1);

		JButton time4_dok2 = new JButton();
		time4_dok2.setHorizontalAlignment(SwingConstants.CENTER);
		time4_dok2.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time4_dok2.setBounds(248, 344, 87, 86);
		panel4.add(time4_dok2);

		JButton time4_dok3 = new JButton();
		time4_dok3.setHorizontalAlignment(SwingConstants.CENTER);
		time4_dok3.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time4_dok3.setBounds(336, 344, 87, 86);
		panel4.add(time4_dok3);

		JButton time4_dok4 = new JButton();
		time4_dok4.setHorizontalAlignment(SwingConstants.CENTER);
		time4_dok4.setBorder(new MatteBorder(0, 1, 1, 0, (Color) new Color(227, 227, 227)));
		time4_dok4.setBounds(424, 344, 87, 86);
		panel4.add(time4_dok4);

		JButton time4_dok5 = new JButton();
		time4_dok5.setHorizontalAlignment(SwingConstants.CENTER);
		time4_dok5.setBorder(new MatteBorder(0, 1, 1, 1, (Color) new Color(227, 227, 227)));
		time4_dok5.setBounds(510, 344, 87, 86);
		panel4.add(time4_dok5);

		// ������������
		List<TimeDTO> list4_dok = dao.listTime1("����", s4);
		JButton[] l20 = new JButton[5];
		l20[0] = time4_dok1;
		l20[1] = time4_dok2;
		l20[2] = time4_dok3;
		l20[3] = time4_dok4;
		l20[4] = time4_dok5;

		for (int i = 0; i < list4_dok.size(); i++) {
			StringBuffer sb = new StringBuffer();
			sb.append(list4_dok.get(i).getStartTime() + " ");
			sb.insert(2, ":");
			l20[i].setText("<html><center>" + list4_dok.get(i).getScreenName() + " ��/ " + sb.toString() + "<br>"
					+ list4_dok.get(i).getSeatNumber() + "��</center></html>");
			
			l20[i].addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					YemaeFrame f = new YemaeFrame(memcode, list4_dok.get(i).getScreenplayCode());
					f.setVisible(true);

				}
			});
		}

		fr.getContentPane().add(tPane);
		fr.setTitle("HONG ����");
		fr.setSize(615, 499);
		fr.setVisible(true);
		fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

	// ���콺������
	@Override
	public void actionPerformed(ActionEvent e) {

	}
}
